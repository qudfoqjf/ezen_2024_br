package 팀과제.팀과제3.model;

public class 농협 extends Dto {
    public int 포인트;
    농협(String 계좌, int 금액, String 이름){
        this.계좌번호=계좌;
        this.계좌주=이름;
        this.입금액=금액;
    }
}
